# Bulk-Email-Sender
A Python script to send bulk or mass emails to email list in an excel file

Video Based Tutorial:
https://youtu.be/qHyE4YAFIv0
